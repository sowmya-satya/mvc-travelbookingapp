package com.mindtree.travelbookingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelbookingappApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelbookingappApplication.class, args);
	}

}
