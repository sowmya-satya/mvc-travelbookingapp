package com.mindtree.uservehicleapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelbookingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
